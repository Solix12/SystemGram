package com.salikh.systemgram.mdels;

import java.util.Date;

public class ChatMessage {

    public String senderId, receiverId, message, dataTime;
    public Date dateObject;
    public String conversionId , conversionName , conversionImage ;

}
