package com.salikh.systemgram.listeners;

import com.salikh.systemgram.mdels.User;

public interface ConversionListener {

    void onConversionClicked(User user);

}
