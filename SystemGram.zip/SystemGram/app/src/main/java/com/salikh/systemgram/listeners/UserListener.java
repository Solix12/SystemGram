package com.salikh.systemgram.listeners;

import com.salikh.systemgram.mdels.User;

public interface UserListener {

    void onUserClicked(User user);
}
